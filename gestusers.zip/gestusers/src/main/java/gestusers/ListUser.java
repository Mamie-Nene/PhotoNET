package gestusers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.UtilisateurDAO;

@WebServlet({ "/list"})
public class ListUser extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1073758432626732068L;
	private static final String VUE_LIST_USERS = "/WEB-INF/index.jsp";

	protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException
	{
	 HttpSession session = req.getSession();
	 Object form = session.getAttribute("form");
	 
	 boolean status = false;
	 if(form !=  null)
	 {
		 session.removeAttribute("form");
		 status = true;
	 }
	 
	 req.setAttribute("status", status);
	 req.setAttribute("utilisateurs", UtilisateurDAO.lister() );
	 getServletContext().getRequestDispatcher(VUE_LIST_USERS).forward(req,resp);
	}
}
