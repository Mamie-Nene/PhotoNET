package forms;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import beans.Utilisateur;
import dao.UtilisateurDAO;

public class ModifyUserForm {

		private static final String CHAMP_NOM = "nom";
		private static final String CHAMP_PRENOM = "prenom";
		private static final String CHAMP_LOGIN = "login";
		private static final String CHAMP_PASSWORD = "password";
		
		private boolean status;
		private String statusMessage;
		private Utilisateur utilisateur;
		private HttpServletRequest request;
		private Map<String,String> erreurs;
		
		public ModifyUserForm(HttpServletRequest request)
		{
			this.request = request;
			this.status = false;
			this.erreurs = new HashMap<>();
		}
		
		public boolean modifier()
		{
			String id = request.getParameter("id");
			if(id!=null && id.matches("[0-9]+")) {
				
			String nom = getParameter(CHAMP_NOM);
			String prenom = getParameter(CHAMP_PRENOM);
			String login = getParameter(CHAMP_LOGIN);
			String password = getParameter(CHAMP_PASSWORD);
		
			validerChamps(CHAMP_NOM,CHAMP_PRENOM,CHAMP_LOGIN ,CHAMP_PASSWORD );
				
			if(erreurs.isEmpty())
			{
				utilisateur = new Utilisateur(Integer.parseInt(id),nom,prenom,login,password);
					status = UtilisateurDAO.modifier(utilisateur);
					if(status)
					{
						statusMessage = "modifie avec succes";
						return true;
					}
			}}
			
				statusMessage = "Echec de la modification ";
				return false;
		
		}

		private String getParameter(String parametre)
		{
			String valeur = request.getParameter(parametre);
			if(valeur == null || valeur.trim().isEmpty())
			{
				return null;
			}
			return valeur.trim();
		}
		
		private void validerChamps(String ...champs)
		{
			for(String champ : champs)
			{
				if(getParameter(champ) == null)
				{
					erreurs.put(champ, "Vous devez renseign� ce champ");
				}
			}
		}

		public boolean getStatus() {
			return status;
		}

		public String getStatusMessage() {
			return statusMessage;
		}

		public Utilisateur getUtilisateur() {
			return utilisateur;
		}

		public Map<String, String> getErreurs() {
			return erreurs;
		}
	}
