package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;



import beans.Utilisateur;

public class UtilisateurDAO 
{
 private static ArrayList<Utilisateur> utilisateurs = new ArrayList<Utilisateur>();

 private static Statement statement = null;
 private static Connection connexion = null;
 
 
 private static Statement connectDB() {
	 
	 try {
		 Class.forName("com.mysql.jdbc.Driver"); 
	 }
	 catch(ClassNotFoundException e) { 
	 }
	 try {
		 connexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/javaee", "root", "");
		 statement = connexion.createStatement();
	 }catch(SQLException e) {
	 }
	 
	 
	 return statement;
 }
 
 
 public static boolean ajouter(Utilisateur utilisateur)
 {
	 Statement st = connectDB();
	 int result;
	 if(st == null ) {
		 System.out.println("erreur");
	 }
	 else {
		
		 try {
			 PreparedStatement prStatement = connexion.prepareStatement("INSERT INTO utilisateur(nom,prenom,login,password) VALUES(?,?,?,?);");
			 prStatement.setString(1, utilisateur.getNom());
			 prStatement.setString(2, utilisateur.getPrenom());
			 prStatement.setString(3, utilisateur.getLogin());
			 prStatement.setString(4, utilisateur.getPassword());
			 
			 result = prStatement.executeUpdate();
			 if(result == 0) {
				 return false; 
			 }
		 }
		 catch(SQLException e) {
			 System.out.println(e);
		 } 
	 }
	 
	 return true;
 }
 
 public static ArrayList<Utilisateur> lister()
 {
	 ArrayList<Utilisateur> users = new ArrayList<Utilisateur>();
	 
	 Statement st = connectDB();
	 if(st == null ) {
		 System.out.println("erreur");
	 }
	 else {
		
		 try {
			 ResultSet resultat = st.executeQuery("SELECT * From utilisateur");
			 
			 while(resultat.next()) {
				 int id = resultat.getInt("id");
		    	 String nom = resultat.getString("nom");
		    	 String prenom = resultat.getString("prenom");
		    	 String login = resultat.getString("login");
		    	 String password = resultat.getString("password");
		    	 Utilisateur u = new Utilisateur(id,nom,prenom,login,password);
		    	 users.add(u);
		     }
		 }
		 catch(SQLException e) {
			 System.out.println(e);
		 }
	 }
	 utilisateurs = (ArrayList<Utilisateur>) users.clone();
	 return users;
 }

public static Utilisateur get(int id) {
	for(Utilisateur utilisateur : utilisateurs) 
	{
		if(utilisateur.getId() == id)
		{
			return utilisateur;
		}
	}
	return null;
}
public static Utilisateur get(String login) {
	for(Utilisateur utilisateur : utilisateurs) 
	{
		if(utilisateur.getLogin().equals(login))
		{
			return utilisateur;
		}
	}
	return null;
}



public static boolean supprimer(int id) {
	 Statement st = connectDB();
	 int result;
	 if(st == null ) {
		 System.out.println("erreur");
	 }
	 else {
		 
		 try {
			 PreparedStatement prStatement = connexion.prepareStatement("DELETE FROM utilisateur WHERE id = ? ;");
			 prStatement.setInt(1, id);
			 
			 result = prStatement.executeUpdate();
			 if(result == 0) {
				 return false; 
			 }
		 }
		 catch(SQLException e) {
			 System.out.println(e);
		 } 
	 }
	 
	 return true;
	
}
	

public static boolean modifier(Utilisateur utilisateur) {
	 Statement st = connectDB();
	 int result;
	 if(st == null ) {
		 System.out.println("erreur");
	 }
	 else {
		
		 try {
			 PreparedStatement prStatement = connexion.prepareStatement("UPDATE utilisateur set nom=?,prenom=?,login=?,password=?  WHERE id = ? ;");
			 prStatement.setString(1, utilisateur.getNom());
			 prStatement.setString(2, utilisateur.getPrenom());
			 prStatement.setString(3, utilisateur.getLogin());
			 prStatement.setString(4, utilisateur.getPassword());
			 prStatement.setInt(5, utilisateur.getId());
			 
			 result = prStatement.executeUpdate();
			 if(result == 0) {
				 return false; 
			 }
		 }
		 catch(SQLException e) {
			 System.out.println(e);
		 } 
	 }
	 
	 return true;
	
}
}
