function confirmationSuppression() 
{
	return confirm("Vous etes surs de vouloir supprimer?");
}