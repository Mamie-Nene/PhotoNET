package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.Utilisateur;
import dao.UsersDao;
import forms.LoginForm;


@WebServlet({"/login","/logout"})
public class Login extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	
	private static final String VUE_LOGIN = "/WEB-INF/login.jsp";

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		switch(request.getServletPath()) 
		{
		case "/login" : 
			getServletContext().getRequestDispatcher(VUE_LOGIN).forward(request, response);
			break;
			default:
				request.getSession().invalidate();
				response.sendRedirect(request.getContextPath());
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{ // TODO Auto-generated method stub
		LoginForm form = new LoginForm(request);
		String login = request.getParameter("login");
		Utilisateur user = UsersDao.get(login);
		
		if(form.authentifier()) 
		{
			if(user.getUserRole().equals("administrateur") )
			{
				response.sendRedirect(request.getContextPath()+"/AccueilAdmin?idUser="+user.getId());
			}
			else {
				response.sendRedirect(request.getContextPath()+"/AccueilUserSimple?idUser="+user.getId());
			}
	
		}
		else 
		{
			request.setAttribute("login", form.getLogin());
			getServletContext().getRequestDispatcher(VUE_LOGIN).forward(request, response);
			
		}
		
		

	}
}
