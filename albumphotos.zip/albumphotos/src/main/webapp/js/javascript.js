function confirmSuppression(){
	return confirm("Voulez-vous vraiment supprimer cet utilisateur?");
}